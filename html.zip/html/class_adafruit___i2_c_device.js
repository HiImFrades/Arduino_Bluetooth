var class_adafruit___i2_c_device =
[
    [ "Adafruit_I2CDevice", "class_adafruit___i2_c_device.html#afea8ccedd8c77bff545c97520d8ec31c", null ],
    [ "_read", "class_adafruit___i2_c_device.html#a057354cd908d37ce5b612540d7c7b794", null ],
    [ "address", "class_adafruit___i2_c_device.html#ae02c4691dbe893c3a5a3de478d776062", null ],
    [ "begin", "class_adafruit___i2_c_device.html#ada579d107621ac5f5e56f91f94a93be3", null ],
    [ "detected", "class_adafruit___i2_c_device.html#ac7492b543fe4c0bb0d94a7bf1915cb2a", null ],
    [ "end", "class_adafruit___i2_c_device.html#afe9d8e8a154d29acaaeb1d00ddd8da08", null ],
    [ "maxBufferSize", "class_adafruit___i2_c_device.html#a20c6ac28cbaa9e5f63ef6d4687fd4e60", null ],
    [ "read", "class_adafruit___i2_c_device.html#afeeccb3147b2f0340c65d2c0c1ce3ea6", null ],
    [ "setSpeed", "class_adafruit___i2_c_device.html#a784c398626837ef911ce7e69b0807be7", null ],
    [ "write", "class_adafruit___i2_c_device.html#aa64a3c83aa776a3f383bc1df24ca1998", null ],
    [ "write_then_read", "class_adafruit___i2_c_device.html#af04af7e2918c873215ce949ce05ebe33", null ],
    [ "_addr", "class_adafruit___i2_c_device.html#ac08f1287f0c99b1d989bc5bf08e84470", null ],
    [ "_begun", "class_adafruit___i2_c_device.html#a895a7279d25777c740a32646315d0128", null ],
    [ "_maxBufferSize", "class_adafruit___i2_c_device.html#a514410b8b50390005cd791da82087f94", null ],
    [ "_wire", "class_adafruit___i2_c_device.html#aa862d3d25197f7362ae23a4030072fdd", null ]
];