var dir_b647e52c3f06e1ac2e61f47e056579fe =
[
    [ "i2c_address_detect", "dir_0b257c814649580428438cdd33d3f346.html", "dir_0b257c814649580428438cdd33d3f346" ],
    [ "i2c_readwrite", "dir_08d4257f50cae76a50d789cad414422e.html", "dir_08d4257f50cae76a50d789cad414422e" ],
    [ "i2c_registers", "dir_8398c33b566d2a07ac43a89aa04e1fb2.html", "dir_8398c33b566d2a07ac43a89aa04e1fb2" ],
    [ "i2corspi_register", "dir_7992300062ad8ae9e46685aac2cbfb9d.html", "dir_7992300062ad8ae9e46685aac2cbfb9d" ],
    [ "spi_modetest", "dir_11a7d6396f6fde7526052d595d589984.html", "dir_11a7d6396f6fde7526052d595d589984" ],
    [ "spi_readwrite", "dir_f8804bac0eb625bf22b6f4d79c0fa074.html", "dir_f8804bac0eb625bf22b6f4d79c0fa074" ],
    [ "spi_register_bits", "dir_4eab7ff56357b1957690cc290f763d0b.html", "dir_4eab7ff56357b1957690cc290f763d0b" ],
    [ "spi_registers", "dir_ab4139d515664b5996b0fcfdc923eb4f.html", "dir_ab4139d515664b5996b0fcfdc923eb4f" ]
];