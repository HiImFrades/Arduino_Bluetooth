var dir_bee252b67967acd5468b1f8dd2b640ea =
[
    [ "ContinuousWithDetails.ino", "_continuous_with_details_8ino.html", "_continuous_with_details_8ino" ]
];