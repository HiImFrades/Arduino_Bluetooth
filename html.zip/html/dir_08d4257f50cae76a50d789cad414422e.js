var dir_08d4257f50cae76a50d789cad414422e =
[
    [ "i2c_readwrite.ino", "i2c__readwrite_8ino.html", "i2c__readwrite_8ino" ]
];