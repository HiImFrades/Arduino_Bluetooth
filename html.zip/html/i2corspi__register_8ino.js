var i2corspi__register_8ino =
[
    [ "I2C_ADDRESS", "i2corspi__register_8ino.html#a770f0c15acd838afca500d56b792c6b5", null ],
    [ "SPIDEVICE_CS", "i2corspi__register_8ino.html#a7aae750f798c075d1e676d0dc6dc8d55", null ],
    [ "loop", "i2corspi__register_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "i2corspi__register_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "i2c_dev", "i2corspi__register_8ino.html#af74b2acb5c80bf27f6ffed759e4067c7", null ],
    [ "spi_dev", "i2corspi__register_8ino.html#a27c0d8ef0f97fe3dc0725a4315412a83", null ]
];