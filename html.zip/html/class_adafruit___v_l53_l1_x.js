var class_adafruit___v_l53_l1_x =
[
    [ "Adafruit_VL53L1X", "class_adafruit___v_l53_l1_x.html#a537d00e2d84a302c6bafd2b3c62a4574", null ],
    [ "begin", "class_adafruit___v_l53_l1_x.html#a62efa49763618a2998ac4543d0de9a71", null ],
    [ "clearInterrupt", "class_adafruit___v_l53_l1_x.html#a02b688e13d8836bed6f265cad2617458", null ],
    [ "dataReady", "class_adafruit___v_l53_l1_x.html#aa1d0857e393a00cceec8ae954398139b", null ],
    [ "distance", "class_adafruit___v_l53_l1_x.html#ad644478dac37b71e0ce1a687e596c34c", null ],
    [ "getIntPolarity", "class_adafruit___v_l53_l1_x.html#a94720b785211f9c64fda241fcd1e7c43", null ],
    [ "getTimingBudget", "class_adafruit___v_l53_l1_x.html#a9e899ed7406b8c6dc766c9fa93e93f9f", null ],
    [ "sensorID", "class_adafruit___v_l53_l1_x.html#a5e28f0759a4c273dae34b85605baecfb", null ],
    [ "setIntPolarity", "class_adafruit___v_l53_l1_x.html#a73b6545395c793de4bb7fe8279f9306f", null ],
    [ "setTimingBudget", "class_adafruit___v_l53_l1_x.html#a543f727ece4d39a76181587a5f69504f", null ],
    [ "startRanging", "class_adafruit___v_l53_l1_x.html#ab32f5af4e72fad82f5c898d7dfdd8d0d", null ],
    [ "stopRanging", "class_adafruit___v_l53_l1_x.html#af42376ad86e60261d31a4fce5dd5302c", null ],
    [ "_irq_pin", "class_adafruit___v_l53_l1_x.html#adca28a5835c4e1029e7a04b321a28678", null ],
    [ "_shutdown_pin", "class_adafruit___v_l53_l1_x.html#a34c033a2fc13ba72afd361bde40eb90b", null ],
    [ "vl_status", "class_adafruit___v_l53_l1_x.html#a104acfad13c0c7b516a20777f51506ee", null ]
];