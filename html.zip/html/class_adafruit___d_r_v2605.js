var class_adafruit___d_r_v2605 =
[
    [ "Adafruit_DRV2605", "class_adafruit___d_r_v2605.html#a7fa13a605887177847327fad47ccd5e6", null ],
    [ "begin", "class_adafruit___d_r_v2605.html#a26c2211e6d16ac90107cc397a79574fb", null ],
    [ "go", "class_adafruit___d_r_v2605.html#a0f1fde6e309b52e810de5bb73aeff3a4", null ],
    [ "init", "class_adafruit___d_r_v2605.html#adf4aaba9319a6519ceda515593b99085", null ],
    [ "readRegister8", "class_adafruit___d_r_v2605.html#a3e4bc9e017aa1df6835b4ff86fe0bb1e", null ],
    [ "selectLibrary", "class_adafruit___d_r_v2605.html#a45d1d167042df97d8e7b8fa2d3cc4123", null ],
    [ "setMode", "class_adafruit___d_r_v2605.html#a63353abae9487a835497143768066fd8", null ],
    [ "setRealtimeValue", "class_adafruit___d_r_v2605.html#a411f7e752367128558116196bd4ac10b", null ],
    [ "setWaveform", "class_adafruit___d_r_v2605.html#a40bf30ec7a2bf03aa884f63111e4a9ac", null ],
    [ "stop", "class_adafruit___d_r_v2605.html#a9e01f4c1f632fe677dfc9c2ef50cf784", null ],
    [ "useERM", "class_adafruit___d_r_v2605.html#a97e3fe0fde61ce059f3e61f356c5c813", null ],
    [ "useLRA", "class_adafruit___d_r_v2605.html#acbf81f99658ddac4d6744a5525408d90", null ],
    [ "writeRegister8", "class_adafruit___d_r_v2605.html#a785d7cfc093bae09be12731d8769058e", null ],
    [ "i2c_dev", "class_adafruit___d_r_v2605.html#ad18cbcaf1c1bd0186aa4f946c3af521a", null ]
];