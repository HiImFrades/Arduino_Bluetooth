var hierarchy =
[
    [ "Adafruit_BusIO_Register", "class_adafruit___bus_i_o___register.html", null ],
    [ "Adafruit_BusIO_RegisterBits", "class_adafruit___bus_i_o___register_bits.html", null ],
    [ "Adafruit_DRV2605", "class_adafruit___d_r_v2605.html", null ],
    [ "Adafruit_I2CDevice", "class_adafruit___i2_c_device.html", null ],
    [ "Adafruit_SPIDevice", "class_adafruit___s_p_i_device.html", null ],
    [ "ComponentObject", "class_component_object.html", [
      [ "RangeSensor", "class_range_sensor.html", [
        [ "VL53L1X", "class_v_l53_l1_x.html", [
          [ "Adafruit_VL53L1X", "class_adafruit___v_l53_l1_x.html", null ]
        ] ]
      ] ]
    ] ],
    [ "DetectionConfig", "struct_detection_config.html", null ],
    [ "gpi_ctl", "structgpi__ctl.html", null ],
    [ "haptic_driver", "structhaptic__driver.html", null ],
    [ "Haptic_DRV2605", "class_haptic___d_r_v2605.html", null ],
    [ "VL53L1X::RangingData", "struct_v_l53_l1_x_1_1_ranging_data.html", null ],
    [ "VL53L1X::ResultBuffer", "struct_v_l53_l1_x_1_1_result_buffer.html", null ],
    [ "scr_mask_type", "structscr__mask__type.html", null ],
    [ "scr_type", "structscr__type.html", null ],
    [ "SFEVL53L1X", "class_s_f_e_v_l53_l1_x.html", null ],
    [ "StructCap", "struct_struct_cap.html", null ],
    [ "StructCap::StructStretch", "struct_struct_cap_1_1_struct_stretch.html", null ],
    [ "StructCap::StructTickCapture", "struct_struct_cap_1_1_struct_tick_capture.html", null ],
    [ "VL53L1_Dev_t", "struct_v_l53_l1___dev__t.html", null ],
    [ "VL53L1X_Dev_t", "struct_v_l53_l1_x___dev__t.html", null ],
    [ "VL53L1X_Version_t", "struct_v_l53_l1_x___version__t.html", null ]
];