var dir_f8804bac0eb625bf22b6f4d79c0fa074 =
[
    [ "spi_readwrite.ino", "spi__readwrite_8ino.html", "spi__readwrite_8ino" ]
];