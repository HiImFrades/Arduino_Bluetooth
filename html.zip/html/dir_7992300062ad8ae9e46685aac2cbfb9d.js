var dir_7992300062ad8ae9e46685aac2cbfb9d =
[
    [ "i2corspi_register.ino", "i2corspi__register_8ino.html", "i2corspi__register_8ino" ]
];