var structscr__mask__type =
[
    [ "mask", "structscr__mask__type.html#a598be10c43d9a6d8dec2d17eca136a7b", null ],
    [ "reg", "structscr__mask__type.html#acba0d67279897616624717a07e910385", null ],
    [ "val", "structscr__mask__type.html#a1453d241de73d1acea3fc26035479d51", null ]
];