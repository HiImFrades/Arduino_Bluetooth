var searchData=
[
  ['calcmacroperiod_0',['calcMacroPeriod',['../class_v_l53_l1_x.html#a31d662cd9edf4fd2f01efd31c13ff574',1,'VL53L1X']]],
  ['calibrateoffset_1',['calibrateOffset',['../class_s_f_e_v_l53_l1_x.html#a065fe899fb87135976c0cc3991683794',1,'SFEVL53L1X']]],
  ['calibratextalk_2',['calibrateXTalk',['../class_s_f_e_v_l53_l1_x.html#ae807ff42f9f9fca83ef2ca0e9af4a519',1,'SFEVL53L1X']]],
  ['checkbootstate_3',['checkBootState',['../class_s_f_e_v_l53_l1_x.html#a373c91279760e844eaf3ad938f4d1a8a',1,'SFEVL53L1X']]],
  ['checkfaults_4',['checkFaults',['../spi__register__bits_8ino.html#aed8e5329606ca8747c73c01de95ef8ac',1,'spi_register_bits.ino']]],
  ['checkfordataready_5',['checkForDataReady',['../class_s_f_e_v_l53_l1_x.html#a0d6037ab9472e1998e2055e9e1702cc9',1,'SFEVL53L1X']]],
  ['checkid_6',['checkID',['../class_s_f_e_v_l53_l1_x.html#a85d09af5e2a5f27990a1d122cbc1756e',1,'SFEVL53L1X']]],
  ['checktimeoutexpired_7',['checkTimeoutExpired',['../class_v_l53_l1_x.html#a89fc937cc7a99dbe6837467eff15f125',1,'VL53L1X']]],
  ['clearinterrupt_8',['clearInterrupt',['../class_adafruit___v_l53_l1_x.html#a02b688e13d8836bed6f265cad2617458',1,'Adafruit_VL53L1X::clearInterrupt()'],['../class_s_f_e_v_l53_l1_x.html#a80e27207bd9dd35acbc1e8836e1fd07c',1,'SFEVL53L1X::clearInterrupt()']]],
  ['countratefixedtofloat_9',['countRateFixedToFloat',['../class_v_l53_l1_x.html#adbf56764ad635d355c302a9acec329ab',1,'VL53L1X']]]
];
