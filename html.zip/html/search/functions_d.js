var searchData=
[
  ['rangestatustostring_0',['rangeStatusToString',['../class_v_l53_l1_x.html#ab64c3a6681bd21bdae7f467812e3160a',1,'VL53L1X']]],
  ['read_1',['read',['../class_adafruit___bus_i_o___register.html#a2b48e23dacbb7cffc0eb07dcebcfba6f',1,'Adafruit_BusIO_Register::read(uint8_t *buffer, uint8_t len)'],['../class_adafruit___bus_i_o___register.html#adca04654563a7c68a580533197366f61',1,'Adafruit_BusIO_Register::read(uint8_t *value)'],['../class_adafruit___bus_i_o___register.html#a5c49c498815a5414d6fb5915760bbeba',1,'Adafruit_BusIO_Register::read(uint16_t *value)'],['../class_adafruit___bus_i_o___register.html#a699434b2567ae8fce541b8048d891252',1,'Adafruit_BusIO_Register::read(void)'],['../class_adafruit___bus_i_o___register_bits.html#a868614bb793ae3c4c00b7954896213d0',1,'Adafruit_BusIO_RegisterBits::read()'],['../class_adafruit___i2_c_device.html#afeeccb3147b2f0340c65d2c0c1ce3ea6',1,'Adafruit_I2CDevice::read()'],['../class_adafruit___s_p_i_device.html#a5c4fce15c92a0210c0872a827f239ab1',1,'Adafruit_SPIDevice::read()'],['../class_v_l53_l1_x.html#a9405c3b3148333d269cd952a34cec0d2',1,'VL53L1X::read()']]],
  ['readcached_2',['readCached',['../class_adafruit___bus_i_o___register.html#a9738fbb8c088d5cf6d381f87dc9288bb',1,'Adafruit_BusIO_Register']]],
  ['readid_3',['ReadID',['../class_component_object.html#aee572ee1421cb3bae31974e9795b472a',1,'ComponentObject::ReadID()'],['../class_v_l53_l1_x.html#aaad6c2f0e55cb85307545d700d107fe7',1,'VL53L1X::ReadID()'],['../class_component_object.html#aee572ee1421cb3bae31974e9795b472a',1,'ComponentObject::ReadID()'],['../class_v_l53_l1_x.html#aaad6c2f0e55cb85307545d700d107fe7',1,'VL53L1X::ReadID()']]],
  ['readrangecontinuousmillimeters_4',['readRangeContinuousMillimeters',['../class_v_l53_l1_x.html#aa4241f38d60735014a3b0e21f3bfe617',1,'VL53L1X']]],
  ['readrangesinglemillimeters_5',['readRangeSingleMillimeters',['../class_v_l53_l1_x.html#af235fa92cab74306ff5ab3085f19e183',1,'VL53L1X']]],
  ['readreg_6',['readReg',['../class_haptic___d_r_v2605.html#ad39c31b7f14f62653b38851479e15924',1,'Haptic_DRV2605::readReg()'],['../class_v_l53_l1_x.html#ae87f9265fc0a8448f3ac400bf221cedf',1,'VL53L1X::readReg(regAddr reg)']]],
  ['readreg16bit_7',['readReg16Bit',['../class_v_l53_l1_x.html#aba2c84060df46045bab07edf6f94bd8b',1,'VL53L1X']]],
  ['readreg32bit_8',['readReg32Bit',['../class_v_l53_l1_x.html#a98fb38066e5672b444c919904da2eb9c',1,'VL53L1X']]],
  ['readregister8_9',['readRegister8',['../class_adafruit___d_r_v2605.html#a3e4bc9e017aa1df6835b4ff86fe0bb1e',1,'Adafruit_DRV2605']]],
  ['readresults_10',['readResults',['../class_v_l53_l1_x.html#a79ba77e772ed537487ca38388f87d558',1,'VL53L1X']]],
  ['readsingle_11',['readSingle',['../class_v_l53_l1_x.html#a66a90be9bc1dd8e8dc23caaf092acf31',1,'VL53L1X']]],
  ['readwaveformbulk_12',['readWaveformBulk',['../class_haptic___d_r_v2605.html#a0c119df794bc53944086fa9a6311c29f',1,'Haptic_DRV2605']]],
  ['rratio2c_13',['rRatio2C',['../spi__register__bits_8ino.html#a20e9184ac3390ef2800cf75191dd0df9',1,'spi_register_bits.ino']]]
];
