var searchData=
[
  ['phasecal_5fconfig_5f_5ftimeout_5fmacrop_0',['PHASECAL_CONFIG__TIMEOUT_MACROP',['../_adafruit___v_l53_l1_x_2src_2vl53l1x__class_8h.html#ab27d045e59238e549647e80fae3573f8',1,'PHASECAL_CONFIG__TIMEOUT_MACROP:&#160;vl53l1x_class.h'],['../_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2src_2st__src_2vl53l1x__class_8h.html#ab27d045e59238e549647e80fae3573f8',1,'PHASECAL_CONFIG__TIMEOUT_MACROP:&#160;vl53l1x_class.h']]]
];
