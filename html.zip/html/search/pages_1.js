var searchData=
[
  ['capturetimer_20_3ca_20href_3d_22https_3a_2f_2ftravis_2dci_2ecom_2fsmfsw_2fcapturetimer_22_20_3e_3cimg_20src_3d_22https_3a_2f_2ftravis_2dci_2ecom_2fsmfsw_2fcapturetimer_2esvg_3fbranch_3dmaster_22_20alt_3d_22build_20status_22_2f_3e_3c_2fa_3e_0',['CaptureTimer &lt;a href=&quot;https://travis-ci.com/SMFSW/CaptureTimer&quot; &gt;&lt;img src=&quot;https://travis-ci.com/SMFSW/CaptureTimer.svg?branch=master&quot; alt=&quot;Build Status&quot;/&gt;&lt;/a&gt;',['../md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html',1,'']]]
];
