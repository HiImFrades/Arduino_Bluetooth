var searchData=
[
  ['newdistance_0',['newDistance',['../_example5___l_c_d_demo_8ino.html#a4725648870209ca5ce8ad37334555249',1,'Example5_LCDDemo.ino']]],
  ['numberofdeltas_1',['numberOfDeltas',['../_example5___l_c_d_demo_8ino.html#afa040ce86b4d83c8512e988a83a088f3',1,'Example5_LCDDemo.ino']]]
];
