var searchData=
[
  ['busio_5fhas_5fhw_5fspi_0',['BUSIO_HAS_HW_SPI',['../_adafruit___s_p_i_device_8h.html#a6cb6c773b07186398c394a1b2b88c806',1,'Adafruit_SPIDevice.h']]]
];
