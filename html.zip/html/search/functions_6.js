var searchData=
[
  ['filterring_0',['filterRing',['../spi__register__bits_8ino.html#a8d2c3cd1368262713c4a6787dddb8a1b',1,'spi_register_bits.ino']]],
  ['funnotificacion_1',['funNotificacion',['../bluetooth_8ino.html#acb59054450d753993e95114c5885abe3',1,'bluetooth.ino']]]
];
