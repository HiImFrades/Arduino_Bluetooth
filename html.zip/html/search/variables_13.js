var searchData=
[
  ['waveform_0',['waveform',['../_e_r_m__basic_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;ERM_basic.ino'],['../_e_r_m__coin_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;ERM_coin.ino'],['../_l_r_a__basic_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;LRA_basic.ino']]],
  ['waveforms_5fmax_1',['waveforms_max',['../_e_r_m__basic_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;ERM_basic.ino'],['../_e_r_m__coin_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;ERM_coin.ino'],['../_l_r_a__basic_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;LRA_basic.ino']]],
  ['windowmode_2',['windowMode',['../struct_detection_config.html#a36949ed182fc0b17374120292a34f947',1,'DetectionConfig']]],
  ['wire_5fbit_3',['wire_bit',['../spi__register__bits_8ino.html#a744cf21c3dcf8e1d126551320dd617a8',1,'spi_register_bits.ino']]]
];
