var searchData=
[
  ['adafruit_5fbusio_5fspiregtype_0',['Adafruit_BusIO_SPIRegType',['../_adafruit___bus_i_o___register_8h.html#a071c4a820b1ac412da2d42c7c61cb219',1,'Adafruit_BusIO_Register.h']]],
  ['adafruit_5fi2cregister_1',['Adafruit_I2CRegister',['../_adafruit___i2_c_register_8h.html#a54801c392b2db2b783afd2b787e7cbbb',1,'Adafruit_I2CRegister.h']]],
  ['adafruit_5fi2cregisterbits_2',['Adafruit_I2CRegisterBits',['../_adafruit___i2_c_register_8h.html#a5df0c4d963bdcbb3b8928d4a64ba8d95',1,'Adafruit_I2CRegister.h']]]
];
