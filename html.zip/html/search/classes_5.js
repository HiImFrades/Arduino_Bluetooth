var searchData=
[
  ['rangesensor_0',['RangeSensor',['../class_range_sensor.html',1,'']]],
  ['rangingdata_1',['RangingData',['../struct_v_l53_l1_x_1_1_ranging_data.html',1,'VL53L1X']]],
  ['resultbuffer_2',['ResultBuffer',['../struct_v_l53_l1_x_1_1_result_buffer.html',1,'VL53L1X']]]
];
