var searchData=
[
  ['ones_5fbit_0',['oneS_bit',['../spi__register__bits_8ino.html#a4ae36fe9389654dd1a6fa21c0791939b',1,'spi_register_bits.ino']]],
  ['op_5fmode_1',['op_mode',['../structhaptic__driver.html#a672e52b8b7239e7668304842f827c442',1,'haptic_driver']]],
  ['orden_2',['orden',['../bluetooth_8ino.html#a8446122a6759dac8806cf892366c6d31',1,'bluetooth.ino']]],
  ['osc_5fcalibrate_5fval_3',['osc_calibrate_val',['../class_v_l53_l1_x.html#af21afd70f911123119c65852bd5ac96e',1,'VL53L1X']]],
  ['overflowing_4',['overflowing',['../namespace_ms_timer2.html#a25615cb530ed6bbc2b6964abd65f1924',1,'MsTimer2']]]
];
