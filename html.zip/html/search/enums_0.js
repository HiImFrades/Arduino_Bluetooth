var searchData=
[
  ['_5fadafruit_5fbusio_5fspiregtype_0',['_Adafruit_BusIO_SPIRegType',['../_adafruit___bus_i_o___register_8h.html#aab8187a2a7855dbdafc14106289f7c52',1,'Adafruit_BusIO_Register.h']]]
];
