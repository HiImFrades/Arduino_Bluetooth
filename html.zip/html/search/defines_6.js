var searchData=
[
  ['haptic_5fbusy_0',['HAPTIC_BUSY',['../_haptic___d_r_v2605_8h.html#a6e620a5835a5a80db5af7b7cb31e0e0c',1,'Haptic_DRV2605.h']]],
  ['haptic_5fchip_5fid_1',['HAPTIC_CHIP_ID',['../_haptic___d_r_v2605_8h.html#abda0240099a27d4ea09cd658c5c42e04',1,'Haptic_DRV2605.h']]],
  ['haptic_5ferr_5fio_2',['HAPTIC_ERR_IO',['../_haptic___d_r_v2605_8h.html#a0dbb4deaeac5a5ddb2e7994f7cc14c27',1,'Haptic_DRV2605.h']]],
  ['haptic_5ferr_5fplatform_3',['HAPTIC_ERR_PLATFORM',['../_haptic___d_r_v2605_8h.html#a41429d83e03d4be2fb1ca60e29eb043d',1,'Haptic_DRV2605.h']]],
  ['haptic_5ffail_4',['HAPTIC_FAIL',['../_haptic___d_r_v2605_8h.html#ad0390b5c2101f07733f113f0a8734ba1',1,'Haptic_DRV2605.h']]],
  ['haptic_5fill_5faddr_5',['HAPTIC_ILL_ADDR',['../_haptic___d_r_v2605_8h.html#a832d61023e997a836730ee18f2b8332e',1,'Haptic_DRV2605.h']]],
  ['haptic_5fill_5farg_6',['HAPTIC_ILL_ARG',['../_haptic___d_r_v2605_8h.html#a2ae12d092d189992eccb907566bc1943',1,'Haptic_DRV2605.h']]],
  ['haptic_5fill_5fio_7',['HAPTIC_ILL_IO',['../_haptic___d_r_v2605_8h.html#a6b463454455ec9f5e1e3aa6394360823',1,'Haptic_DRV2605.h']]],
  ['haptic_5fill_5fstate_8',['HAPTIC_ILL_STATE',['../_haptic___d_r_v2605_8h.html#a8212b876e5626886bd780aebc20a911c',1,'Haptic_DRV2605.h']]],
  ['haptic_5fno_5fresource_9',['HAPTIC_NO_RESOURCE',['../_haptic___d_r_v2605_8h.html#acefc7d0082b83c2d8b2e9f103a656681',1,'Haptic_DRV2605.h']]],
  ['haptic_5fnot_5fsupported_10',['HAPTIC_NOT_SUPPORTED',['../_haptic___d_r_v2605_8h.html#ad2176e85a15cd535c13e578928155cfc',1,'Haptic_DRV2605.h']]],
  ['haptic_5fsuccess_11',['HAPTIC_SUCCESS',['../_haptic___d_r_v2605_8h.html#a259f56e8333365d30f0ed829a3ce1651',1,'Haptic_DRV2605.h']]],
  ['haptic_5ftimeout_12',['HAPTIC_TIMEOUT',['../_haptic___d_r_v2605_8h.html#a846c43b18cf7fefa0ff53b5f40ed080e',1,'Haptic_DRV2605.h']]],
  ['history_5fsize_13',['HISTORY_SIZE',['../_example3___status_and_rate_8ino.html#a43034bdd0ae7c6267b05ff35ae97cddf',1,'HISTORY_SIZE:&#160;Example3_StatusAndRate.ino'],['../_example5___l_c_d_demo_8ino.html#a43034bdd0ae7c6267b05ff35ae97cddf',1,'HISTORY_SIZE:&#160;Example5_LCDDemo.ino']]]
];
