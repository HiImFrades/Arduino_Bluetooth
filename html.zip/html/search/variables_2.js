var searchData=
[
  ['bemf_5fsense_5fen_0',['bemf_sense_en',['../structhaptic__driver.html#a262d1ad70e9ac34d1fcc4a9c019a465c',1,'haptic_driver']]],
  ['bias_5fbit_1',['bias_bit',['../spi__register__bits_8ino.html#ad13e924a52171836ef0400943b355f9e',1,'spi_register_bits.ino']]],
  ['build_2',['build',['../struct_v_l53_l1_x___version__t.html#a03c80c16cb2de79265289251f14a1643',1,'VL53L1X_Version_t']]],
  ['bus_3',['bus',['../class_v_l53_l1_x.html#a653a73e11437ae8c83449fefa28a7efc',1,'VL53L1X']]]
];
