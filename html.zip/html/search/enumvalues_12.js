var searchData=
[
  ['vhv_5fconfig_5f_5fcount_5fthresh_0',['VHV_CONFIG__COUNT_THRESH',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a6d9bffe6c52795d6c917c26aceba0d5f',1,'VL53L1X']]],
  ['vhv_5fconfig_5f_5finit_1',['VHV_CONFIG__INIT',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945aaea1475de83b882fafe4f16a654ce5fd',1,'VL53L1X']]],
  ['vhv_5fconfig_5f_5foffset_2',['VHV_CONFIG__OFFSET',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945adf50d20774d426ee8e76021bbaa59a2a',1,'VL53L1X']]],
  ['vhv_5fconfig_5f_5ftimeout_5fmacrop_5floop_5fbound_3',['VHV_CONFIG__TIMEOUT_MACROP_LOOP_BOUND',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945aef3a41ba10a5e032526817d220b80f83',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fcoldboot_5fstatus_4',['VHV_RESULT__COLDBOOT_STATUS',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a44da30452b0a5a9a475218c9116e254a',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5flatest_5fsetting_5',['VHV_RESULT__LATEST_SETTING',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945af1a11cf4ad9855e03f9ff3bf35e2da7c',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fpeak_5fsignal_5frate_5fmcps_6',['VHV_RESULT__PEAK_SIGNAL_RATE_MCPS',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945aa5bd244fa6d733b7ed92202347ae61c3',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fpeak_5fsignal_5frate_5fmcps_5fhi_7',['VHV_RESULT__PEAK_SIGNAL_RATE_MCPS_HI',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a1555ed7fae28016dfe6f224fec1b70e1',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fpeak_5fsignal_5frate_5fmcps_5flo_8',['VHV_RESULT__PEAK_SIGNAL_RATE_MCPS_LO',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a46cf74f603782c4389271c17f3bc8772',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsearch_5fresult_9',['VHV_RESULT__SEARCH_RESULT',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a6f4846fa6712fe6a40ccf9bfcdc65868',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsignal_5ftotal_5fevents_5fref_10',['VHV_RESULT__SIGNAL_TOTAL_EVENTS_REF',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a70a293e6ef1a8e8203e910158ac29f7c',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsignal_5ftotal_5fevents_5fref_5f0_11',['VHV_RESULT__SIGNAL_TOTAL_EVENTS_REF_0',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a920e00885509fd0ad6add536edfb4507',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsignal_5ftotal_5fevents_5fref_5f1_12',['VHV_RESULT__SIGNAL_TOTAL_EVENTS_REF_1',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a4a34b2479d711f6b69a9c03bcf929139',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsignal_5ftotal_5fevents_5fref_5f2_13',['VHV_RESULT__SIGNAL_TOTAL_EVENTS_REF_2',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945adf212dc5116e4671725c9cef77690c69',1,'VL53L1X']]],
  ['vhv_5fresult_5f_5fsignal_5ftotal_5fevents_5fref_5f3_14',['VHV_RESULT__SIGNAL_TOTAL_EVENTS_REF_3',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945acdf1d49e597f60efc248f89c536d0cb8',1,'VL53L1X']]]
];
