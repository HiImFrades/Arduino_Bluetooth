var searchData=
[
  ['busiobitorder_0',['BusIOBitOrder',['../_adafruit___s_p_i_device_8h.html#ad65ace9d1f2e952e782eef68a6deeef3',1,'Adafruit_SPIDevice.h']]]
];
