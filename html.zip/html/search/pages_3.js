var searchData=
[
  ['license_0',['LICENSE',['../md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_l_i_c_e_n_s_e.html',1,'(Global Namespace)'],['../md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___dccf2883bbad1fa94cb771be42a0e8bc5.html',1,'(Global Namespace)'],['../md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___d4915c311fa55ec84aa8fa93bfda7badf.html',1,'(Global Namespace)']]]
];
