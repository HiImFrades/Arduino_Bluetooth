var searchData=
[
  ['ones_5fbit_0',['oneS_bit',['../spi__register__bits_8ino.html#a4ae36fe9389654dd1a6fa21c0791939b',1,'spi_register_bits.ino']]],
  ['op_5fmode_1',['op_mode',['../structhaptic__driver.html#a672e52b8b7239e7668304842f827c442',1,'haptic_driver::op_mode'],['../_haptic___d_r_v2605_8h.html#a071fae3a2219bd5494a968e2453a90c2',1,'op_mode:&#160;Haptic_DRV2605.h']]],
  ['orden_2',['orden',['../bluetooth_8ino.html#a8446122a6759dac8806cf892366c6d31',1,'bluetooth.ino']]],
  ['osc_5fcalibrate_5fval_3',['osc_calibrate_val',['../class_v_l53_l1_x.html#af21afd70f911123119c65852bd5ac96e',1,'VL53L1X']]],
  ['osc_5fmeasured_5f_5ffast_5fosc_5f_5ffrequency_4',['OSC_MEASURED__FAST_OSC__FREQUENCY',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945aab2a4bd646ffa83134e4588aeaaa7eee',1,'VL53L1X']]],
  ['osc_5fmeasured_5f_5ffast_5fosc_5f_5ffrequency_5fhi_5',['OSC_MEASURED__FAST_OSC__FREQUENCY_HI',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a86687b031256b466e868b5d5386b7d96',1,'VL53L1X']]],
  ['osc_5fmeasured_5f_5ffast_5fosc_5f_5ffrequency_5flo_6',['OSC_MEASURED__FAST_OSC__FREQUENCY_LO',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945ae9589f341c874565971713a5d424b922',1,'VL53L1X']]],
  ['outmaxvalue_7',['outMaxValue',['../_capture_to_analogic_8ino.html#aebf07d67f9eda0506d03ff07582c3ba6',1,'CaptureToAnalogic.ino']]],
  ['outofboundsfail_8',['OutOfBoundsFail',['../class_v_l53_l1_x.html#aebe19bf26b9d89b3a464014035aed6cba6cf64396c6d10f3664b1a0db488d9252',1,'VL53L1X']]],
  ['outpin_9',['outPin',['../_capture_to_analogic_8ino.html#ae94c5e5531153195f896bd7796e7cfdb',1,'CaptureToAnalogic.ino']]],
  ['overflowing_10',['overflowing',['../namespace_ms_timer2.html#a25615cb530ed6bbc2b6964abd65f1924',1,'MsTimer2']]]
];
