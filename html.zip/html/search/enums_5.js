var searchData=
[
  ['rangestatus_0',['RangeStatus',['../class_v_l53_l1_x.html#aebe19bf26b9d89b3a464014035aed6cb',1,'VL53L1X']]],
  ['regaddr_1',['regAddr',['../class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945',1,'VL53L1X']]]
];
