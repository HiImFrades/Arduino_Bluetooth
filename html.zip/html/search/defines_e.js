var searchData=
[
  ['tickoutpin_0',['tickOUTPin',['../_capture_to_analogic_8ino.html#adb5e07b95b308bd25bc02a39160e802f',1,'tickOUTPin:&#160;CaptureToAnalogic.ino'],['../_simple_capture_8ino.html#adb5e07b95b308bd25bc02a39160e802f',1,'tickOUTPin:&#160;SimpleCapture.ino'],['../_triggered_tick_capture_8ino.html#adb5e07b95b308bd25bc02a39160e802f',1,'tickOUTPin:&#160;TriggeredTickCapture.ino']]],
  ['tone_5fpin_1',['TONE_PIN',['../_example6___arduino_plotter_output_8ino.html#abab0dbef357276596d81c7ada190b428',1,'TONE_PIN:&#160;Example6_ArduinoPlotterOutput.ino'],['../_example7___calibration_8ino.html#abab0dbef357276596d81c7ada190b428',1,'TONE_PIN:&#160;Example7_Calibration.ino']]]
];
