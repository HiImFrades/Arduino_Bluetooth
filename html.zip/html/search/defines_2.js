var searchData=
[
  ['capturetimer_5fver_0',['CaptureTimer_ver',['../_capture_timer_8h.html#a4a1935c13eb833e945222f3eb672cf25',1,'CaptureTimer.h']]],
  ['ctinpin_1',['ctINPin',['../_simple_capture_8ino.html#a6a974d311ba62c2ce0adc6235de29907',1,'ctINPin:&#160;SimpleCapture.ino'],['../_triggered_tick_capture_8ino.html#a6a974d311ba62c2ce0adc6235de29907',1,'ctINPin:&#160;TriggeredTickCapture.ino']]]
];
