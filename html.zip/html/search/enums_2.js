var searchData=
[
  ['gpi_5fmodes_0',['gpi_modes',['../_haptic___d_r_v2605_8h.html#aedb9bd3409b9b4db5ef7fdbef5f69d17',1,'Haptic_DRV2605.h']]],
  ['gpi_5fpolarity_1',['gpi_polarity',['../_haptic___d_r_v2605_8h.html#a47fef181512572565bae2f078cdbe813',1,'Haptic_DRV2605.h']]]
];
