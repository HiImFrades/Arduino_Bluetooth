var searchData=
[
  ['detectionconfig_0',['DetectionConfig',['../struct_detection_config.html',1,'']]]
];
