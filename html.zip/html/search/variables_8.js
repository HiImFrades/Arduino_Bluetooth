var searchData=
[
  ['haptic_0',['haptic',['../_e_r_m__basic_8ino.html#ad5c4454795b817f1ef23fc7b91cef350',1,'haptic:&#160;ERM_basic.ino'],['../_e_r_m__coin_8ino.html#ad5c4454795b817f1ef23fc7b91cef350',1,'haptic:&#160;ERM_coin.ino'],['../_e_r_m__complex_8ino.html#ad5c4454795b817f1ef23fc7b91cef350',1,'haptic:&#160;ERM_complex.ino'],['../_e_r_m__scripts_8ino.html#ad5c4454795b817f1ef23fc7b91cef350',1,'haptic:&#160;ERM_scripts.ino'],['../_l_r_a__basic_8ino.html#ad5c4454795b817f1ef23fc7b91cef350',1,'haptic:&#160;LRA_basic.ino']]],
  ['haptic_5fcomplex1_1',['haptic_complex1',['../_haptic___d_r_v2605_8cpp.html#ad43a577a51646b2d8501685f23520c32',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5fcomplex2_2',['haptic_complex2',['../_haptic___d_r_v2605_8cpp.html#aa7efd8a69afd766b4694eafbe892be68',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5fcomplex3_3',['haptic_complex3',['../_haptic___d_r_v2605_8cpp.html#a11e8e15b9c63560ed359452c18a7d2fe',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5ferm_5fbasic_4',['haptic_ERM_basic',['../_haptic___d_r_v2605_8cpp.html#a39f7934ac20a7d16c442e832449f0076',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5ferm_5fcoin_5',['haptic_ERM_coin',['../_haptic___d_r_v2605_8cpp.html#a70e916e8a24cba124265bd8aa2703c9c',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5fi2c_5faddress_6',['Haptic_I2C_Address',['../class_haptic___d_r_v2605.html#a8b8ab7a4299f0b08edbbedf1525781a0',1,'Haptic_DRV2605']]],
  ['haptic_5flra_5fbasic_7',['haptic_LRA_basic',['../_haptic___d_r_v2605_8cpp.html#a976d37a00594f930e81da628ee430fc6',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5flra_5fcalibrate_8',['haptic_LRA_calibrate',['../_haptic___d_r_v2605_8cpp.html#a0c43d2d02eb797dd2a1de7ecd58eae1f',1,'Haptic_DRV2605.cpp']]],
  ['haptic_5freset_9',['haptic_reset',['../_haptic___d_r_v2605_8cpp.html#a7fb7da0bd5e849bcb185d035d5f95762',1,'Haptic_DRV2605.cpp']]],
  ['history_10',['history',['../_example3___status_and_rate_8ino.html#ab9b89fc47f41cd0bcfdfa382e969036e',1,'history:&#160;Example3_StatusAndRate.ino'],['../_example5___l_c_d_demo_8ino.html#ab9b89fc47f41cd0bcfdfa382e969036e',1,'history:&#160;Example5_LCDDemo.ino']]],
  ['historyspot_11',['historySpot',['../_example3___status_and_rate_8ino.html#aff1ba20dd91f190f3d0893cebe85ce5c',1,'historySpot:&#160;Example3_StatusAndRate.ino'],['../_example5___l_c_d_demo_8ino.html#aff1ba20dd91f190f3d0893cebe85ce5c',1,'historySpot:&#160;Example5_LCDDemo.ino']]]
];
