var searchData=
[
  ['effect_0',['effect',['../bluetooth_8ino.html#aff207385d59c41944d09014acaec2481',1,'effect:&#160;bluetooth.ino'],['../basic_8ino.html#aff207385d59c41944d09014acaec2481',1,'effect:&#160;basic.ino']]]
];
