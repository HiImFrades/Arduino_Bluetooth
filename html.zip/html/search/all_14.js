var searchData=
[
  ['waveform_0',['waveform',['../_e_r_m__basic_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;ERM_basic.ino'],['../_e_r_m__coin_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;ERM_coin.ino'],['../_l_r_a__basic_8ino.html#a4869c26fbe68aa53959121780e1d8f8d',1,'waveform:&#160;LRA_basic.ino']]],
  ['waveforms_5fmax_1',['waveforms_max',['../_e_r_m__basic_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;ERM_basic.ino'],['../_e_r_m__coin_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;ERM_coin.ino'],['../_l_r_a__basic_8ino.html#ab2a8af484cc917d29ba511f56f163755',1,'waveforms_max:&#160;LRA_basic.ino']]],
  ['width_2',['width',['../class_adafruit___bus_i_o___register.html#abf1eaeb0ae836be082a73dae14e7e352',1,'Adafruit_BusIO_Register']]],
  ['window_5fabove_3',['WINDOW_ABOVE',['../_spark_fun___v_l53_l1_x_8h.html#ae7881ad719476c8e622a10938356e917',1,'SparkFun_VL53L1X.h']]],
  ['window_5fbelow_4',['WINDOW_BELOW',['../_spark_fun___v_l53_l1_x_8h.html#a079ca47a6c5892038dbd67e0fd142e40',1,'SparkFun_VL53L1X.h']]],
  ['window_5fin_5',['WINDOW_IN',['../_spark_fun___v_l53_l1_x_8h.html#a7707d256389b6624691990f28695fd54',1,'SparkFun_VL53L1X.h']]],
  ['window_5fout_6',['WINDOW_OUT',['../_spark_fun___v_l53_l1_x_8h.html#af343a073fcf040145baf32640367b702',1,'SparkFun_VL53L1X.h']]],
  ['windowmode_7',['windowMode',['../struct_detection_config.html#a36949ed182fc0b17374120292a34f947',1,'DetectionConfig']]],
  ['wire_5fbit_8',['wire_bit',['../spi__register__bits_8ino.html#a744cf21c3dcf8e1d126551320dd617a8',1,'spi_register_bits.ino']]],
  ['wraptargetfail_9',['WrapTargetFail',['../class_v_l53_l1_x.html#aebe19bf26b9d89b3a464014035aed6cba2bcb8a7ca7af6aca85a110d7392fd476',1,'VL53L1X']]],
  ['write_10',['write',['../class_adafruit___bus_i_o___register.html#aa418dced5301a1d8c1776a1941c8bc64',1,'Adafruit_BusIO_Register::write(uint8_t *buffer, uint8_t len)'],['../class_adafruit___bus_i_o___register.html#adad13ec14c8548eaeff62609077aa076',1,'Adafruit_BusIO_Register::write(uint32_t value, uint8_t numbytes=0)'],['../class_adafruit___bus_i_o___register_bits.html#a9311f94f1a1d93bc575b06c34ddecd80',1,'Adafruit_BusIO_RegisterBits::write()'],['../class_adafruit___i2_c_device.html#aa64a3c83aa776a3f383bc1df24ca1998',1,'Adafruit_I2CDevice::write()'],['../class_adafruit___s_p_i_device.html#a1c984896fcc5d009511ce37a659fdb2e',1,'Adafruit_SPIDevice::write(const uint8_t *buffer, size_t len, const uint8_t *prefix_buffer=nullptr, size_t prefix_len=0)']]],
  ['write_5fand_5fread_11',['write_and_read',['../class_adafruit___s_p_i_device.html#a808c81bc4b9e42d064b9f590a1f6b1bd',1,'Adafruit_SPIDevice']]],
  ['write_5fthen_5fread_12',['write_then_read',['../class_adafruit___i2_c_device.html#af04af7e2918c873215ce949ce05ebe33',1,'Adafruit_I2CDevice::write_then_read()'],['../class_adafruit___s_p_i_device.html#a9cc3386cab3750aa18bbf3918261fc54',1,'Adafruit_SPIDevice::write_then_read()']]],
  ['writereg_13',['writeReg',['../class_haptic___d_r_v2605.html#a77fcaece550c6a40057813c35ff65978',1,'Haptic_DRV2605::writeReg()'],['../class_v_l53_l1_x.html#a48032917a44757169a336969f4d3d0f4',1,'VL53L1X::writeReg(uint16_t reg, uint8_t value)']]],
  ['writereg16bit_14',['writeReg16Bit',['../class_v_l53_l1_x.html#a1545772dc19af7d6b21d7fe798b29245',1,'VL53L1X']]],
  ['writereg32bit_15',['writeReg32Bit',['../class_v_l53_l1_x.html#a99d2d945018c3386c06419521e2d18c5',1,'VL53L1X']]],
  ['writeregbits_16',['writeRegBits',['../class_haptic___d_r_v2605.html#a3b4ffd464a424d23f0caa26190d7eda9',1,'Haptic_DRV2605']]],
  ['writeregbulk_17',['writeRegBulk',['../class_haptic___d_r_v2605.html#ac6e71eae0febc6bd716fe0e9f84b521a',1,'Haptic_DRV2605']]],
  ['writeregister8_18',['writeRegister8',['../class_adafruit___d_r_v2605.html#a785d7cfc093bae09be12731d8769058e',1,'Adafruit_DRV2605']]],
  ['writeregscript_19',['writeRegScript',['../class_haptic___d_r_v2605.html#a2623946046f9c35d4534ff71ec99d411',1,'Haptic_DRV2605']]],
  ['writewaveformbulk_20',['writeWaveformBulk',['../class_haptic___d_r_v2605.html#aae1fb62d99e7cdb8ac273498d44cffe1',1,'Haptic_DRV2605']]]
];
