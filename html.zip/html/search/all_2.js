var searchData=
[
  ['basic_2eino_0',['basic.ino',['../basic_8ino.html',1,'']]],
  ['begin_1',['begin',['../class_adafruit___i2_c_device.html#ada579d107621ac5f5e56f91f94a93be3',1,'Adafruit_I2CDevice::begin()'],['../class_adafruit___s_p_i_device.html#a6aa3c0bebb1d2d58516bce4f2dd1423f',1,'Adafruit_SPIDevice::begin()'],['../class_adafruit___d_r_v2605.html#a26c2211e6d16ac90107cc397a79574fb',1,'Adafruit_DRV2605::begin()'],['../class_adafruit___v_l53_l1_x.html#a62efa49763618a2998ac4543d0de9a71',1,'Adafruit_VL53L1X::begin()'],['../class_v_l53_l1_x.html#a05f691e11ef48537b1f621e7c7551b0d',1,'VL53L1X::begin()'],['../class_haptic___d_r_v2605.html#a0e3f24a839d5d8aee9ca7beaf9ce6c4d',1,'Haptic_DRV2605::begin()'],['../class_s_f_e_v_l53_l1_x.html#a30e3ae5860f35dc03ba21914bed12c8c',1,'SFEVL53L1X::begin()'],['../class_s_f_e_v_l53_l1_x.html#a3df7e64c4223d9c3655e557e2c7f8518',1,'SFEVL53L1X::begin(TwoWire &amp;i2cPort)']]],
  ['begintransaction_2',['beginTransaction',['../class_adafruit___s_p_i_device.html#acde87a3312ddc729c259b1b45fe71d82',1,'Adafruit_SPIDevice']]],
  ['begintransactionwithassertingcs_3',['beginTransactionWithAssertingCS',['../class_adafruit___s_p_i_device.html#a11e91bf075cdd77edcec11f4b28c6292',1,'Adafruit_SPIDevice']]],
  ['bemf_5fsense_5fen_4',['bemf_sense_en',['../structhaptic__driver.html#a262d1ad70e9ac34d1fcc4a9c019a465c',1,'haptic_driver']]],
  ['bias_5fbit_5',['bias_bit',['../spi__register__bits_8ino.html#ad13e924a52171836ef0400943b355f9e',1,'spi_register_bits.ino']]],
  ['bluetooth_2eino_6',['bluetooth.ino',['../bluetooth_8ino.html',1,'']]],
  ['both_5fedge_7',['BOTH_EDGE',['../_haptic___d_r_v2605_8h.html#a47fef181512572565bae2f078cdbe813a2ad5d7903c9b0d8e40f69be6654d8760',1,'Haptic_DRV2605.h']]],
  ['bt_8',['BT',['../bluetooth_8ino.html#a15ce6f109f11df86251555271949e769',1,'bluetooth.ino']]],
  ['build_9',['build',['../struct_v_l53_l1_x___version__t.html#a03c80c16cb2de79265289251f14a1643',1,'VL53L1X_Version_t']]],
  ['bus_10',['bus',['../class_v_l53_l1_x.html#a653a73e11437ae8c83449fefa28a7efc',1,'VL53L1X']]],
  ['busio_5fhas_5fhw_5fspi_11',['BUSIO_HAS_HW_SPI',['../_adafruit___s_p_i_device_8h.html#a6cb6c773b07186398c394a1b2b88c806',1,'Adafruit_SPIDevice.h']]],
  ['busiobitorder_12',['BusIOBitOrder',['../_adafruit___s_p_i_device_8h.html#ad65ace9d1f2e952e782eef68a6deeef3',1,'Adafruit_SPIDevice.h']]]
];
