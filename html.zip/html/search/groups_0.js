var searchData=
[
  ['error_20and_20warning_20code_20returned_20by_20api_0',['Error and Warning code returned by API',['../group___v_l53_l1__define___error__group.html',1,'(Global Namespace)'],['../group___v_l53_l1_x__define___error__group.html',1,'(Global Namespace)']]]
];
