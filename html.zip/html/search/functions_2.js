var searchData=
[
  ['begin_0',['begin',['../class_adafruit___i2_c_device.html#ada579d107621ac5f5e56f91f94a93be3',1,'Adafruit_I2CDevice::begin()'],['../class_adafruit___s_p_i_device.html#a6aa3c0bebb1d2d58516bce4f2dd1423f',1,'Adafruit_SPIDevice::begin()'],['../class_adafruit___d_r_v2605.html#a26c2211e6d16ac90107cc397a79574fb',1,'Adafruit_DRV2605::begin()'],['../class_adafruit___v_l53_l1_x.html#a62efa49763618a2998ac4543d0de9a71',1,'Adafruit_VL53L1X::begin()'],['../class_v_l53_l1_x.html#a05f691e11ef48537b1f621e7c7551b0d',1,'VL53L1X::begin()'],['../class_haptic___d_r_v2605.html#a0e3f24a839d5d8aee9ca7beaf9ce6c4d',1,'Haptic_DRV2605::begin()'],['../class_s_f_e_v_l53_l1_x.html#a30e3ae5860f35dc03ba21914bed12c8c',1,'SFEVL53L1X::begin()'],['../class_s_f_e_v_l53_l1_x.html#a3df7e64c4223d9c3655e557e2c7f8518',1,'SFEVL53L1X::begin(TwoWire &amp;i2cPort)']]],
  ['begintransaction_1',['beginTransaction',['../class_adafruit___s_p_i_device.html#acde87a3312ddc729c259b1b45fe71d82',1,'Adafruit_SPIDevice']]],
  ['begintransactionwithassertingcs_2',['beginTransactionWithAssertingCS',['../class_adafruit___s_p_i_device.html#a11e91bf075cdd77edcec11f4b28c6292',1,'Adafruit_SPIDevice']]],
  ['bt_3',['BT',['../bluetooth_8ino.html#a15ce6f109f11df86251555271949e769',1,'bluetooth.ino']]]
];
