var searchData=
[
  ['i2c_5faddress_5fdetect_2eino_0',['i2c_address_detect.ino',['../i2c__address__detect_8ino.html',1,'']]],
  ['i2c_5freadwrite_2eino_1',['i2c_readwrite.ino',['../i2c__readwrite_8ino.html',1,'']]],
  ['i2c_5fregisters_2eino_2',['i2c_registers.ino',['../i2c__registers_8ino.html',1,'']]],
  ['i2corspi_5fregister_2eino_3',['i2corspi_register.ino',['../i2corspi__register_8ino.html',1,'']]]
];
