var searchData=
[
  ['haptic_5fdrv2605_0',['Haptic_DRV2605',['../class_haptic___d_r_v2605.html#a4c72adf7f9b7c0b832198412267c2e1a',1,'Haptic_DRV2605::Haptic_DRV2605(void)'],['../class_haptic___d_r_v2605.html#a5656ad879d7ac1bf90fc841a42fef8d7',1,'Haptic_DRV2605::Haptic_DRV2605(int8_t gp0_pin)']]]
];
