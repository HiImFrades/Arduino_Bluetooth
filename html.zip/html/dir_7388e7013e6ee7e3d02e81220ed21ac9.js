var dir_7388e7013e6ee7e3d02e81220ed21ac9 =
[
    [ "Example8_SetGetDetectionThresholds.ino", "_example8___set_get_detection_thresholds_8ino.html", "_example8___set_get_detection_thresholds_8ino" ]
];