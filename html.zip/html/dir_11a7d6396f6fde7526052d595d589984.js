var dir_11a7d6396f6fde7526052d595d589984 =
[
    [ "spi_modetest.ino", "spi__modetest_8ino.html", "spi__modetest_8ino" ]
];