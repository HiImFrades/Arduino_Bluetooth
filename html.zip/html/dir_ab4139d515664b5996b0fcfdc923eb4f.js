var dir_ab4139d515664b5996b0fcfdc923eb4f =
[
    [ "spi_registers.ino", "spi__registers_8ino.html", "spi__registers_8ino" ]
];