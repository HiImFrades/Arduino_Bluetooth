var class_component_object =
[
    [ "Init", "class_component_object.html#ae74ef194c6daaa0733ff97279f825821", null ],
    [ "Init", "class_component_object.html#ae74ef194c6daaa0733ff97279f825821", null ],
    [ "ReadID", "class_component_object.html#aee572ee1421cb3bae31974e9795b472a", null ],
    [ "ReadID", "class_component_object.html#aee572ee1421cb3bae31974e9795b472a", null ]
];