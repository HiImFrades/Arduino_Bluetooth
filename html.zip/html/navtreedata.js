/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "bluetooth", "index.html", [
    [ "Adafruit DRV2605L Haptic Driver", "index.html", "index" ],
    [ "Adafruit Bus IO Library <a href=\"https://github.com/adafruit/Adafruit_BusIO/actions\" ><img src=\"https://github.com/adafruit/Adafruit_BusIO/workflows/Arduino%20Library%20CI/badge.svg\" alt=\"Build Status\"/></a>", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___bus_i_o_2_r_e_a_d_m_e.html", null ],
    [ "Adafruit Community Code of Conduct", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html", [
      [ "Our Pledge", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md2", null ],
      [ "Our Standards", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md3", null ],
      [ "Our Responsibilities", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md4", null ],
      [ "Moderation", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md5", null ],
      [ "Scope", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md6", null ],
      [ "Attribution", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2code-of-conduct.html#autotoc_md7", null ]
    ] ],
    [ "Adafruit DRV2605 Library <a href=\"https://github.com/adafruit/Adafruit_DRV2605_Library/actions\" ><img src=\"https://github.com/adafruit/Adafruit_DRV2605_Library/workflows/Arduino%20Library%20CI/badge.svg\" alt=\"Build Status\"/></a>", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___d_r_v2605___library_2_r_e_a_d_m_e.html", null ],
    [ "LICENSE", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_l_i_c_e_n_s_e.html", null ],
    [ "Adafruit VL53L1X Library <a href=\"https://travis-ci.com/adafruit/Adafruit_VL53L1X\" ><img src=\"https://travis-ci.com/adafruit/Adafruit_VL53L1X.svg?branch=master\" alt=\"Build Status\"/></a> <a href=\"http://adafruit.github.io/Adafruit_VL53L1X/html/index.html\" ><img src=\"https://github.com/adafruit/ci-arduino/blob/master/assets/doxygen_badge.svg\" alt=\"Documentation\"/></a>", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_r_e_a_d_m_e.html", [
      [ "API", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md10", null ],
      [ "Note", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md11", null ],
      [ "Documentation", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_adafruit___v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md12", null ]
    ] ],
    [ "CaptureTimer <a href=\"https://travis-ci.com/SMFSW/CaptureTimer\" ><img src=\"https://travis-ci.com/SMFSW/CaptureTimer.svg?branch=master\" alt=\"Build Status\"/></a>", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html", [
      [ "Notes", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html#autotoc_md14", null ],
      [ "Usage", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html#autotoc_md15", null ],
      [ "Examples included", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html#autotoc_md16", null ],
      [ "Documentation", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html#autotoc_md17", null ],
      [ "Release Notes", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_r_e_a_d_m_e.html#autotoc_md18", null ]
    ] ],
    [ "ReleaseNotes", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_capture_timer_2_release_notes.html", null ],
    [ "Haptic_DRV2605 Arduino Library", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html", [
      [ "Repository Contents", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html#autotoc_md21", null ],
      [ "Documentation", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html#autotoc_md22", null ],
      [ "Products that use this Library", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html#autotoc_md23", null ],
      [ "Compatible Products that (can) use this Library", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html#autotoc_md24", null ],
      [ "Version History", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_haptic___d_r_v2605_2_r_e_a_d_m_e.html#autotoc_md25", null ]
    ] ],
    [ "README", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_ms_timer2_2_r_e_a_d_m_e.html", null ],
    [ "LICENSE", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___dccf2883bbad1fa94cb771be42a0e8bc5.html", null ],
    [ "SparkFun Qwiic 4m Distance Sensor with VL53L1X", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2_r_e_a_d_m_e.html", [
      [ "Repository Contents", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2_r_e_a_d_m_e.html#autotoc_md31", null ],
      [ "Documentation", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2_r_e_a_d_m_e.html#autotoc_md32", null ],
      [ "Products that use this Library", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2_r_e_a_d_m_e.html#autotoc_md33", null ],
      [ "License Information", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2_r_e_a_d_m_e.html#autotoc_md34", null ]
    ] ],
    [ "LICENSE", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_spark_fun___v_l53_l1_x__4m___laser___d4915c311fa55ec84aa8fa93bfda7badf.html", null ],
    [ "VL53L1X library for Arduino", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html", [
      [ "Summary", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md36", null ],
      [ "Supported platforms", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md37", null ],
      [ "Getting started", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md38", [
        [ "Hardware", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md39", [
          [ "5V Arduino boards", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md40", null ],
          [ "3.3V Arduino boards", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md41", null ]
        ] ],
        [ "Software", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md42", null ]
      ] ],
      [ "Examples", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md43", null ],
      [ "ST's VL53L1X API and this library", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md44", null ],
      [ "Library reference", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md45", null ],
      [ "Version history", "md__c_1_2_users_2victo_2_documents_2_arduino_2libraries_2_v_l53_l1_x_2_r_e_a_d_m_e.html#autotoc_md46", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", "functions_eval" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_adafruit___bus_i_o___register_8cpp.html",
"_example5___l_c_d_demo_8ino.html#aff1ba20dd91f190f3d0893cebe85ce5c",
"_spark_fun___v_l53_l1_x__4m___laser___distance___sensor_2src_2st__src_2vl53l1x__class_8h.html#aeb992f2c9bfd1c73dcfae9ebc7180fad",
"class_s_f_e_v_l53_l1_x.html#add979eaa0fc85c45bd529136863d7722",
"class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a218cb703a49efcb1d89fd5752c309dc5",
"class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a528528257d41e244aab94aae04fbd20f",
"class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945a90238c76bc568d3eed66ee51acac8f6e",
"class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945ac457991629d9b3a736970cade01b8036",
"class_v_l53_l1_x.html#a630fe91f7dda45c2bab28dc4b906c945afb2ae0c1fb5453efa2c9bae52e7a9cab",
"functions_func.html",
"namespace_capture_timer.html#a57454203517480a673bde898a4908053"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';