var dir_8398c33b566d2a07ac43a89aa04e1fb2 =
[
    [ "i2c_registers.ino", "i2c__registers_8ino.html", "i2c__registers_8ino" ]
];