var dir_4eab7ff56357b1957690cc290f763d0b =
[
    [ "spi_register_bits.ino", "spi__register__bits_8ino.html", "spi__register__bits_8ino" ]
];