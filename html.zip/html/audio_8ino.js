var audio_8ino =
[
    [ "loop", "audio_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "audio_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "drv", "audio_8ino.html#a7aaf31c44a943dd240d0ca64a02bec50", null ]
];