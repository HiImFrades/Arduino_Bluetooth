var dir_54c95b49cbb72e87a1af2d7512c6841b =
[
    [ "realtime.ino", "realtime_8ino.html", "realtime_8ino" ]
];