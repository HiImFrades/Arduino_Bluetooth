var structgpi__ctl =
[
    [ "mode", "structgpi__ctl.html#a0300eab5ae5a3bf5c076e9518646ff87", null ],
    [ "polarity", "structgpi__ctl.html#abbd4681b70e04855a7ffe034a686c65a", null ],
    [ "seq_id", "structgpi__ctl.html#ab08a3e45c83a39f3298427af5d7729e1", null ]
];