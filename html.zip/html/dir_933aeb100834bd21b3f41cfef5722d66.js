var dir_933aeb100834bd21b3f41cfef5722d66 =
[
    [ "Haptic_DRV2605.cpp", "_haptic___d_r_v2605_8cpp.html", "_haptic___d_r_v2605_8cpp" ],
    [ "Haptic_DRV2605.h", "_haptic___d_r_v2605_8h.html", "_haptic___d_r_v2605_8h" ],
    [ "Haptic_DRV2605_registers.h", "_haptic___d_r_v2605__registers_8h.html", "_haptic___d_r_v2605__registers_8h" ]
];