var structhaptic__driver =
[
    [ "acc_en", "structhaptic__driver.html#ad810506daa2a1760c84c9d38673966c0", null ],
    [ "amp_pid_en", "structhaptic__driver.html#ae77a0a54326f8574519819cd91e62a3c", null ],
    [ "bemf_sense_en", "structhaptic__driver.html#a262d1ad70e9ac34d1fcc4a9c019a465c", null ],
    [ "dev_lib", "structhaptic__driver.html#ad4a8db14ce52a3b6f973eb136f125c35", null ],
    [ "dev_libs_max", "structhaptic__driver.html#a0e038915935c741d86544cd38d0eb0e8", null ],
    [ "dev_script", "structhaptic__driver.html#a2216caeb255528245c3e52fe584e56d3", null ],
    [ "dev_scripts_max", "structhaptic__driver.html#a1136b48176da5d2ecc92e1d94b1647d9", null ],
    [ "dev_state", "structhaptic__driver.html#a899829d8646b3e7566031ce4452834af", null ],
    [ "dev_type", "structhaptic__driver.html#acba6985a574c49a35a8ab3af73706fa1", null ],
    [ "dev_waveform", "structhaptic__driver.html#a0b6c6e350bd61c983da4772982ddebc6", null ],
    [ "dev_waveforms_max", "structhaptic__driver.html#a30be3feeb5ba6b47da6ffd5ead0d3b9d", null ],
    [ "freq_track_en", "structhaptic__driver.html#a6d25a25cd4b77a9307b70f2f63164ff4", null ],
    [ "op_mode", "structhaptic__driver.html#a672e52b8b7239e7668304842f827c442", null ],
    [ "rapid_stop_en", "structhaptic__driver.html#a449597f4d151e52eb5741bc458ac0cc0", null ]
];