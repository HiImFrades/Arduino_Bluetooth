var dir_32f284423e1ca1d089f5815f7d4e3602 =
[
    [ "Continuous", "dir_7fe84ec708e4b52e49ec0b5c77c10568.html", "dir_7fe84ec708e4b52e49ec0b5c77c10568" ],
    [ "ContinuousMultipleSensors", "dir_7518f5a7746e3e8d3d46b5e6c2a4702e.html", "dir_7518f5a7746e3e8d3d46b5e6c2a4702e" ],
    [ "ContinuousWithDetails", "dir_bee252b67967acd5468b1f8dd2b640ea.html", "dir_bee252b67967acd5468b1f8dd2b640ea" ]
];