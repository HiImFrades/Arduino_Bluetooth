var namespaces_dup =
[
    [ "CaptureTimer", "namespace_capture_timer.html", [
      [ "__attribute__", "namespace_capture_timer.html#ad674117c8570712966b8a1c4d8364d8a", null ],
      [ "getScaledTicks", "namespace_capture_timer.html#a9b3f39de56a55a0ae5eaccf5b1113e20", null ],
      [ "getTickCapture", "namespace_capture_timer.html#a54d0c025f2ff761de33214f9c9937c45", null ],
      [ "getTicks", "namespace_capture_timer.html#ac6aa51e7e5713c83fe55ab7acfd133ad", null ],
      [ "initCapTicks", "namespace_capture_timer.html#aacccbeebcd828ba6306cafbe8ea9f67e", null ],
      [ "initCapTime", "namespace_capture_timer.html#a57454203517480a673bde898a4908053", null ],
      [ "isrTick_event", "namespace_capture_timer.html#aa1f60f51fcce98e1df6f9b6f197402b7", null ],
      [ "perStretch", "namespace_capture_timer.html#af22820656100be1bf4327007f2b25356", null ],
      [ "setFilterSpeed", "namespace_capture_timer.html#a90d49a79704039ecca5dc7e7c47e83f6", null ],
      [ "setPeriod", "namespace_capture_timer.html#a636d14461bd8cc899990cc0a6e9e555f", null ],
      [ "startTickCapture", "namespace_capture_timer.html#ae47d726ffc79c6b39028fccec7580153", null ],
      [ "_cap", "namespace_capture_timer.html#a0133b15dfc35f0e25e4798d0771ebe05", null ],
      [ "filt", "namespace_capture_timer.html#a43ea771bc2c2e6786a470add18d3e506", null ]
    ] ],
    [ "MsTimer2", "namespace_ms_timer2.html", [
      [ "_overflow", "namespace_ms_timer2.html#ab5e628bd9addf94a80d6bc5e0760b400", null ],
      [ "set", "namespace_ms_timer2.html#a5afd2e98541af95cd82bc4f443287c6a", null ],
      [ "start", "namespace_ms_timer2.html#a0421c92f5359f0c2f3e07a0a6c479ba2", null ],
      [ "stop", "namespace_ms_timer2.html#a04d48ca8508c5192f08b0a823d22b05d", null ],
      [ "count", "namespace_ms_timer2.html#a3b94010d575f715ce30b1508d98e79c9", null ],
      [ "func", "namespace_ms_timer2.html#aff1de832b6f17d65691ce123baa1b6f9", null ],
      [ "msecs", "namespace_ms_timer2.html#a5c1a7d4078da8dd273ca47091f69cf88", null ],
      [ "overflowing", "namespace_ms_timer2.html#a25615cb530ed6bbc2b6964abd65f1924", null ],
      [ "tcnt2", "namespace_ms_timer2.html#a3dc9386d120b03337f4c2c30fb69b129", null ]
    ] ]
];