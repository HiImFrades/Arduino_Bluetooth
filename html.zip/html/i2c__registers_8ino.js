var i2c__registers_8ino =
[
    [ "I2C_ADDRESS", "i2c__registers_8ino.html#a770f0c15acd838afca500d56b792c6b5", null ],
    [ "loop", "i2c__registers_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "i2c__registers_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "i2c_dev", "i2c__registers_8ino.html#a608873b902a557587d5ad23f57baba2b", null ]
];