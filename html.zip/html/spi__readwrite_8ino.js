var spi__readwrite_8ino =
[
    [ "SPIDEVICE_CS", "spi__readwrite_8ino.html#a7aae750f798c075d1e676d0dc6dc8d55", null ],
    [ "loop", "spi__readwrite_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "spi__readwrite_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "spi_dev", "spi__readwrite_8ino.html#aa51d3a5286ce439063776a8aa6a8b1e5", null ]
];