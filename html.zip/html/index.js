var index =
[
    [ "Introduction", "index.html#intro_sec", null ],
    [ "Author", "index.html#author", null ],
    [ "License", "index.html#license", null ]
];