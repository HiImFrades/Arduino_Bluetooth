var annotated_dup =
[
    [ "Adafruit_BusIO_Register", "class_adafruit___bus_i_o___register.html", "class_adafruit___bus_i_o___register" ],
    [ "Adafruit_BusIO_RegisterBits", "class_adafruit___bus_i_o___register_bits.html", "class_adafruit___bus_i_o___register_bits" ],
    [ "Adafruit_DRV2605", "class_adafruit___d_r_v2605.html", "class_adafruit___d_r_v2605" ],
    [ "Adafruit_I2CDevice", "class_adafruit___i2_c_device.html", "class_adafruit___i2_c_device" ],
    [ "Adafruit_SPIDevice", "class_adafruit___s_p_i_device.html", "class_adafruit___s_p_i_device" ],
    [ "Adafruit_VL53L1X", "class_adafruit___v_l53_l1_x.html", "class_adafruit___v_l53_l1_x" ],
    [ "ComponentObject", "class_component_object.html", "class_component_object" ],
    [ "DetectionConfig", "struct_detection_config.html", "struct_detection_config" ],
    [ "gpi_ctl", "structgpi__ctl.html", "structgpi__ctl" ],
    [ "haptic_driver", "structhaptic__driver.html", "structhaptic__driver" ],
    [ "Haptic_DRV2605", "class_haptic___d_r_v2605.html", "class_haptic___d_r_v2605" ],
    [ "RangeSensor", "class_range_sensor.html", "class_range_sensor" ],
    [ "scr_mask_type", "structscr__mask__type.html", "structscr__mask__type" ],
    [ "scr_type", "structscr__type.html", "structscr__type" ],
    [ "SFEVL53L1X", "class_s_f_e_v_l53_l1_x.html", "class_s_f_e_v_l53_l1_x" ],
    [ "StructCap", "struct_struct_cap.html", "struct_struct_cap" ],
    [ "VL53L1_Dev_t", "struct_v_l53_l1___dev__t.html", "struct_v_l53_l1___dev__t" ],
    [ "VL53L1X", "class_v_l53_l1_x.html", "class_v_l53_l1_x" ],
    [ "VL53L1X_Dev_t", "struct_v_l53_l1_x___dev__t.html", "struct_v_l53_l1_x___dev__t" ],
    [ "VL53L1X_Version_t", "struct_v_l53_l1_x___version__t.html", "struct_v_l53_l1_x___version__t" ]
];