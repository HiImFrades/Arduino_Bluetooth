var bluetooth_8ino =
[
    [ "BT", "bluetooth_8ino.html#a15ce6f109f11df86251555271949e769", null ],
    [ "funNotificacion", "bluetooth_8ino.html#acb59054450d753993e95114c5885abe3", null ],
    [ "loop", "bluetooth_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "bluetooth_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "distanceSensor", "bluetooth_8ino.html#a3141e83ac4b657b23177cf42fa87ac18", null ],
    [ "drv", "bluetooth_8ino.html#a7aaf31c44a943dd240d0ca64a02bec50", null ],
    [ "effect", "bluetooth_8ino.html#aff207385d59c41944d09014acaec2481", null ],
    [ "flagSensor", "bluetooth_8ino.html#ad5a874874c73124885805954e9387f34", null ],
    [ "orden", "bluetooth_8ino.html#a8446122a6759dac8806cf892366c6d31", null ],
    [ "patronAlarma", "bluetooth_8ino.html#a0fa7a5cb31a7989c947035af181a9e6f", null ],
    [ "patronBateria", "bluetooth_8ino.html#a9187cb51632c0a8e86422925ee3023bc", null ],
    [ "patronGmail", "bluetooth_8ino.html#aae398379117375c5f23b2043fb89400e", null ],
    [ "patronLlamada", "bluetooth_8ino.html#a1ad4ba04587e9c64d950cdd8f5829b1d", null ],
    [ "patronPower", "bluetooth_8ino.html#a308ff46c4240c16c38763366da0bd051", null ],
    [ "patronSMS", "bluetooth_8ino.html#ae5cc0f2d3f24c09c57f15359e53fcb1b", null ],
    [ "patronWhatsapp", "bluetooth_8ino.html#a10bc6a72d7c012e1ac4bf297eaab786f", null ]
];