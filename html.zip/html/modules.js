var modules =
[
    [ "Error and Warning code returned by API", "group___v_l53_l1_x__define___error__group.html", "group___v_l53_l1_x__define___error__group" ],
    [ "Error and Warning code returned by API", "group___v_l53_l1__define___error__group.html", "group___v_l53_l1__define___error__group" ]
];